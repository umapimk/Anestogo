# Flow

Fast context → Immediate stabilization → Rank hypotheses → Select highest-information question → Update evidence → Select pathway-level intervention → Observe response → Feed response back into ranking → Continue reassessment.
