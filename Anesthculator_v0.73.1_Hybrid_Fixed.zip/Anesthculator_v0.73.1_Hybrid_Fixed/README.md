# Anesthculator v0.73.1 Hybrid Fixed

This build is based directly on the working v0.73.0 Hybrid source.

## Added
- AF onset question
- AF trigger question
- Action → Response loop retained
- Response history across repeated interventions
- Updated working diagnosis after response
- Editable answers and intelligent timeline

## Test path
1. Open index.html or deploy the whole folder to GitHub Pages.
2. Rhythm / HR change = yes
3. Rhythm type = AF
4. Answer AF onset, stability, trigger and ventricular rate
5. Choose an intervention
6. Record response
7. Review updated diagnosis and Response History

## Safety
Prototype only. Not clinically validated and not for patient care.
